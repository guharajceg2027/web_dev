import React from 'react';
import { useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEnvelope, faPhone, faMapMarkerAlt, faShoppingCart, faInfoCircle, faQuestionCircle, faLock, faGavel } from '@fortawesome/free-solid-svg-icons';
import { faFacebook, faTwitter, faInstagram, faPinterest } from '@fortawesome/free-brands-svg-icons';
import './Footer.css';

const Footer = () => {
  const navigate = useNavigate();

  const handleNavigate = (path) => {
    navigate(path);
    window.scrollTo(0, 0);
  };

  return (
    <footer className="footer bg-success text-white py-5">
      <div className="container">
        <div className="row g-4">
          {/* Company info section */}
          <div className="col-12 col-md-4">
            <h5 className="mb-3 d-flex align-items-center">
              <FontAwesomeIcon icon={faShoppingCart} className="me-2" />
              GroceryCart
            </h5>
            <p className="mb-3 text-white">Your one-stop shop for fresh groceries and household essentials delivered right to your doorstep.</p>
            <p className="text-white">&copy; 2025 GroceryCart. All rights reserved.</p>
          </div>

          {/* Quick links with icons */}
          <div className="col-12 col-md-4">
            <h5 className="mb-3">Quick Links</h5>
            <ul className="list-unstyled">
              <li className="mb-2">
                <span onClick={() => handleNavigate('/about-us')} className="text-white text-decoration-none hover-opacity" style={{ cursor: 'pointer' }}>
                  <FontAwesomeIcon icon={faInfoCircle} className="me-2" />
                  About Us
                </span>
              </li>
              <li className="mb-2">
                <span onClick={() => handleNavigate('/faq')} className="text-white text-decoration-none hover-opacity" style={{ cursor: 'pointer' }}>
                  <FontAwesomeIcon icon={faQuestionCircle} className="me-2" />
                  FAQ
                </span>
              </li>
              <li className="mb-2">
                <span onClick={() => handleNavigate('/privacy-policy')} className="text-white text-decoration-none hover-opacity" style={{ cursor: 'pointer' }}>
                  <FontAwesomeIcon icon={faLock} className="me-2" />
                  Privacy Policy
                </span>
              </li>
              <li className="mb-2">
                <span onClick={() => handleNavigate('/terms-and-conditions')} className="text-white text-decoration-none hover-opacity" style={{ cursor: 'pointer' }}>
                  <FontAwesomeIcon icon={faGavel} className="me-2" />
                  Terms & Conditions
                </span>
              </li>
            </ul>
          </div>

          {/* Contact info section */}
          <div className="col-12 col-md-4">
            <h5 className="mb-3">Contact Us</h5>
            <div className="bg-light p-4 rounded shadow-sm text-dark">
              <p className="mb-2">
                <FontAwesomeIcon icon={faEnvelope} className="me-2 text-success" />
                <a href="mailto:support@grocerycart.com" className="text-dark text-decoration-none">support@grocerycart.com</a>
              </p>
              <p className="mb-2">
                <FontAwesomeIcon icon={faPhone} className="me-2 text-success" />
                <a href="tel:+18001234567" className="text-dark text-decoration-none">+1 (800) 123-4567</a>
              </p>
              <p className="mb-2">
                <FontAwesomeIcon icon={faMapMarkerAlt} className="me-2 text-success" />
                <span>123 Fresh Market Street, Food City, FC 45678</span>
              </p>

              {/* Social media icons */}
              <div className="mt-3 d-flex justify-content-start">
                <a href="https://facebook.com" className="me-3 text-success" aria-label="Facebook" target="_blank" rel="noopener noreferrer">
                  <FontAwesomeIcon icon={faFacebook} size="lg" />
                </a>
                <a href="https://twitter.com" className="me-3 text-success" aria-label="Twitter" target="_blank" rel="noopener noreferrer">
                  <FontAwesomeIcon icon={faTwitter} size="lg" />
                </a>
                <a href="https://instagram.com" className="me-3 text-success" aria-label="Instagram" target="_blank" rel="noopener noreferrer">
                  <FontAwesomeIcon icon={faInstagram} size="lg" />
                </a>
                <a href="https://pinterest.com" className="text-success" aria-label="Pinterest" target="_blank" rel="noopener noreferrer">
                  <FontAwesomeIcon icon={faPinterest} size="lg" />
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom section */}
        <div className="row mt-4 pt-3 border-top">
          <div className="col-12 text-center">
            <p className="small mb-0 text-white">We deliver to most locations. Check our delivery areas for more information.</p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
