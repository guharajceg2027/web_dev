import React, { useContext } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { NavLink } from 'react-router-dom';
import { Navbar, Nav, Container } from 'react-bootstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faHome, faShoppingCart, faShoppingBag,
  faUser, faSignOutAlt, faSignInAlt, faUserPlus
} from '@fortawesome/free-solid-svg-icons';
import { AuthContext } from '../context/AuthContext';

const AppNavbar = () => {
  const { currentUser, logout } = useContext(AuthContext);

  return (
    <Navbar bg="success" variant="dark" expand="lg" sticky="top">
      <Container>
        <Navbar.Brand as={NavLink} to="/" className="fw-bold fs-3 text-white">
          <FontAwesomeIcon icon={faShoppingCart} className="me-2" />
          GroceryCart
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="navbar-nav" />
        <Navbar.Collapse id="navbar-nav">
          <Nav className="ms-auto">
            <Nav.Link
              as={NavLink}
              to="/"
              className={({ isActive }) => `mx-3 ${isActive ? 'active text-light fw-bold' : 'text-light'}`}
            >
              <FontAwesomeIcon icon={faHome} className="me-1" /> Home
            </Nav.Link>

            {currentUser && (
              <>
                <Nav.Link
                  as={NavLink}
                  to="/purchase"
                  className={({ isActive }) => `mx-3 ${isActive ? 'active text-light fw-bold' : 'text-light'}`}
                >
                  <FontAwesomeIcon icon={faShoppingBag} className="me-1" /> Purchase
                </Nav.Link>
                <Nav.Link
                  as={NavLink}
                  to="/cart"
                  className={({ isActive }) => `mx-3 ${isActive ? 'active text-light fw-bold' : 'text-light'}`}
                >
                  <FontAwesomeIcon icon={faShoppingCart} className="me-1" /> Cart
                </Nav.Link>
              </>
            )}

            {currentUser ? (
              <>
                <Nav.Link
                  as={NavLink}
                  to="/profile"
                  className={({ isActive }) => `mx-3 ${isActive ? 'active text-light fw-bold' : 'text-light'}`}
                >
                  <FontAwesomeIcon icon={faUser} className="me-1" /> Profile
                </Nav.Link>
                <Nav.Link
                  onClick={logout}
                  className="mx-3 fw-bold text-light"
                  style={{ cursor: 'pointer' }}
                >
                  <FontAwesomeIcon icon={faSignOutAlt} className="me-1" /> Logout
                </Nav.Link>
              </>
            ) : (
              <>
                <Nav.Link
                  as={NavLink}
                  to="/login"
                  className={({ isActive }) => `mx-3 ${isActive ? 'active text-light fw-bold' : 'text-light'}`}
                >
                  <FontAwesomeIcon icon={faSignInAlt} className="me-1" /> Login
                </Nav.Link>
                <Nav.Link
                  as={NavLink}
                  to="/signup"
                  className={({ isActive }) => `mx-3 ${isActive ? 'active text-light fw-bold' : 'text-light'}`}
                >
                  <FontAwesomeIcon icon={faUserPlus} className="me-1" /> Signup
                </Nav.Link>
              </>
            )}
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default AppNavbar;
