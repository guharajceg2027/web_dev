import React from 'react';
import { Button, Card, Row, Col } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import vegetablesImg from '../assets/vegetables.webp';
import fruitsImg from '../assets/fruits.jpg';
import dairyImg from '../assets/diary.png';
import snacksImg from '../assets/snacks.jpg';
import beveragesImg from '../assets/beverages.jpg';
import bakeryImg from '../assets/bakery.jpg';
import './purchase.css';

const Purchase = ({ isLoggedIn }) => {
  const navigate = useNavigate();

  const categoryImages = {
    Vegetables: vegetablesImg,
    Fruits: fruitsImg,
    Dairy: dairyImg,
    Snacks: snacksImg,
    Beverages: beveragesImg,
    Bakery: bakeryImg,
  };

  const handleShopNow = (category) => {
    if (isLoggedIn) {
      navigate(`/shop/${category}`); // Navigate to the category page
    } else {
      navigate('/login');
    }
  };

  return (
    <div className="purchase-page" style={{ padding: '20px' }}>
    <h2 className="text-center fw-semibold fs-1 my-4" style={{ fontFamily: 'Arial, sans-serif', color: '#198754', fontWeight: '600', fontSize: '2.5rem', marginBottom: '1.5rem', marginTop: '1rem' }}>
  <i className="bi bi-shop me-2"></i>
  Shop by Category
</h2>


      <Row>
        {["Vegetables", "Fruits", "Dairy", "Snacks", "Beverages", "Bakery"].map((item, index) => (
          <Col key={index} sm={6} md={4}>
            <Card className="mb-4 shadow-sm">
              {/* Image with fixed size */}
              <Card.Img 
                variant="top" 
                src={categoryImages[item] || `https://source.unsplash.com/400x300/?${item}`} 
                alt={`${item} category`} 
                style={{ width: '100%', height: '200px', objectFit: 'cover' }} 
              />
              <Card.Body>
                <Card.Title>{item}</Card.Title>
                <Button variant="success" onClick={() => handleShopNow(item)}>Shop Now</Button>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>
    </div>
  );
};

export default Purchase;
