import React from 'react';
import { Card, Row, Col, Container } from 'react-bootstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faBullseye,
  faLeaf,
  faAward,
  faEnvelope
} from '@fortawesome/free-solid-svg-icons';
import { faLinkedin, faTwitter } from '@fortawesome/free-brands-svg-icons';
import './AboutUs.css';
import missionImg from '../assets/mission.jpg';
import qualityImg from '../assets/quality.avif';
import sustainabilityImg from '../assets/sustainable.png';
import ceoImg from '../assets/team1.jpg';
import operationsImg from '../assets/team2.jpeg';
import relationsImg from '../assets/dhoni.jpg';

const AboutUs = () => {
  return (
    <Container fluid className="about-us-container py-5">
      <Container className="page py-5">
        <div className="section-header text-center mb-5" data-aos="fade-up">
          <h2 className="display-4 fw-bold text-primary mb-3">About Us</h2>
          <div className="divider mx-auto"></div>
          <p className="lead mt-4">
            We are passionate about bringing fresh groceries to your door. Our mission is to provide 
            the best quality groceries at affordable prices, delivered right to your doorstep.
          </p>
        </div>

        <Row className="g-4 d-flex align-items-stretch mb-5">
          <Col md={6} lg={4} data-aos="fade-up" data-aos-delay="100">
            <Card className="h-100 card-hover shadow-sm">
              <div className="card-img-container">
                <Card.Img variant="top" src={missionImg} />
                <div className="card-img-overlay">
                  <FontAwesomeIcon icon={faBullseye} className="card-icon" />
                </div>
              </div>
              <Card.Body>
                <Card.Title className="fw-bold text-primary">
                  <FontAwesomeIcon icon={faBullseye} className="me-2" />
                  Our Mission
                </Card.Title>
                <Card.Text>
                  At GroceryCart, we strive to make grocery shopping simple and convenient for everyone. 
                  We aim to provide fresh products directly from local farms to your door.
                  We are committed to offering a wide variety of groceries to meet all your needs, 
                  from pantry staples to fresh produce.
                </Card.Text>
              </Card.Body>
            </Card>
          </Col>

          <Col md={6} lg={4} data-aos="fade-up" data-aos-delay="200">
            <Card className="h-100 card-hover shadow-sm">
              <div className="card-img-container">
                <Card.Img variant="top" src={qualityImg} />
                <div className="card-img-overlay">
                  <FontAwesomeIcon icon={faAward} className="card-icon" />
                </div>
              </div>
              <Card.Body>
                <Card.Title className="fw-bold text-primary">
                  <FontAwesomeIcon icon={faAward} className="me-2" />
                  Quality & Freshness
                </Card.Title>
                <Card.Text>
                  We carefully select our suppliers to ensure that we deliver only the highest quality 
                  and freshest groceries. Your satisfaction is our top priority. Our quality control team 
                  inspects every product before it reaches your doorstep.
                </Card.Text>
              </Card.Body>
            </Card>
          </Col>

          <Col md={6} lg={4} data-aos="fade-up" data-aos-delay="300">
            <Card className="h-100 card-hover shadow-sm">
              <div className="card-img-container">
                <Card.Img variant="top" src={sustainabilityImg} />
                <div className="card-img-overlay">
                  <FontAwesomeIcon icon={faLeaf} className="card-icon" />
                </div>
              </div>
              <Card.Body>
                <Card.Title className="fw-bold text-primary">
                  <FontAwesomeIcon icon={faLeaf} className="me-2" />
                  Sustainable Practices
                </Card.Title>
                <Card.Text>
                  We believe in sustainability and work with eco-friendly packaging and green practices 
                  to reduce our environmental footprint while delivering fresh groceries. We partner with 
                  local farmers who use sustainable farming methods.
                </Card.Text>
              </Card.Body>
            </Card>
          </Col>
        </Row>

        <div className="section-header text-center my-5" data-aos="fade-up">
          <h2 className="display-5 fw-bold text-primary mb-3">Meet the Team</h2>
          <div className="divider mx-auto"></div>
        </div>

        <Row className="g-4 d-flex align-items-stretch">
          <Col md={4} data-aos="fade-up" data-aos-delay="100">
            <Card className="text-center h-100 team-card shadow-sm">
              <div className="team-img-container">
                <Card.Img variant="top" src={ceoImg} />
                <div className="team-overlay">
                  <div className="team-social">
                    {/* Using buttons styled as links for accessibility */}
                    <button className="social-icon" aria-label="LinkedIn Profile">
                      <FontAwesomeIcon icon={faLinkedin} />
                    </button>
                    <button className="social-icon" aria-label="Twitter Profile">
                      <FontAwesomeIcon icon={faTwitter} />
                    </button>
                    <button className="social-icon" aria-label="Email Contact">
                      <FontAwesomeIcon icon={faEnvelope} />
                    </button>
                  </div>
                </div>
              </div>
              <Card.Body>
                <Card.Title className="fw-bold">John Doe</Card.Title>
                <div className="team-position">CEO & Founder</div>
                <Card.Text className="mt-3">
                  With over 15 years of experience in the grocery industry, John leads our company with passion and vision.
                </Card.Text>
              </Card.Body>
            </Card>
          </Col>

          <Col md={4} data-aos="fade-up" data-aos-delay="200">
            <Card className="text-center h-100 team-card shadow-sm">
              <div className="team-img-container">
                <Card.Img variant="top" src={operationsImg} />
                <div className="team-overlay">
                  <div className="team-social">
                    <button className="social-icon" aria-label="LinkedIn Profile">
                      <FontAwesomeIcon icon={faLinkedin} />
                    </button>
                    <button className="social-icon" aria-label="Twitter Profile">
                      <FontAwesomeIcon icon={faTwitter} />
                    </button>
                    <button className="social-icon" aria-label="Email Contact">
                      <FontAwesomeIcon icon={faEnvelope} />
                    </button>
                  </div>
                </div>
              </div>
              <Card.Body>
                <Card.Title className="fw-bold">Jane Smith</Card.Title>
                <div className="team-position">Head of Operations</div>
                <Card.Text className="mt-3">
                  Jane ensures that our operations run smoothly and efficiently to deliver the best service to our customers.
                </Card.Text>
              </Card.Body>
            </Card>
          </Col>

          <Col md={4} data-aos="fade-up" data-aos-delay="300">
            <Card className="text-center h-100 team-card shadow-sm">
              <div className="team-img-container">
                <Card.Img variant="top" src={relationsImg} />
                <div className="team-overlay">
                  <div className="team-social">
                    <button className="social-icon" aria-label="LinkedIn Profile">
                      <FontAwesomeIcon icon={faLinkedin} />
                    </button>
                    <button className="social-icon" aria-label="Twitter Profile">
                      <FontAwesomeIcon icon={faTwitter} />
                    </button>
                    <button className="social-icon" aria-label="Email Contact">
                      <FontAwesomeIcon icon={faEnvelope} />
                    </button>
                  </div>
                </div>
              </div>
              <Card.Body>
                <Card.Title className="fw-bold">David Brown</Card.Title>
                <div className="team-position">Customer Relations Manager</div>
                <Card.Text className="mt-3">
                  David is dedicated to ensuring that our customers have the best experience with our service.
                </Card.Text>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    </Container>
  );
};

export default AboutUs;
