import React from 'react';
import { Accordion, Container, Row, Col, Card } from 'react-bootstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
  faClock, 
  faBan, 
  faMapMarkerAlt, 
  faCreditCard, 
  faShippingFast,
  faQuestionCircle,
  faExchangeAlt,
  faLeaf,
  faShieldAlt,
  faUserPlus
} from '@fortawesome/free-solid-svg-icons';
import './Page.css';

const FAQ = () => (
  <Container className="page py-5">
    <Row className="mb-5">
      <Col>
        <div className="text-center mb-5">
          <FontAwesomeIcon icon={faQuestionCircle} size="3x" className="text-success mb-3" />
          <h2 className="fw-bold text-success">Frequently Asked Questions</h2>
          <p className="text-muted">Find answers to the most common questions about our services</p>
        </div>
      </Col>
    </Row>

    <Row className="mb-4">
      <Col md={4} className="mb-4">
        <Card className="h-100 shadow-sm border-0 faq-category-card">
          <Card.Body className="text-center p-4">
            <FontAwesomeIcon icon={faShippingFast} size="2x" className="text-success mb-3" />
            <Card.Title>Delivery</Card.Title>
            <Card.Text className="text-muted">
              Information about our delivery process, timelines, and service areas.
            </Card.Text>
          </Card.Body>
        </Card>
      </Col>
      <Col md={4} className="mb-4">
        <Card className="h-100 shadow-sm border-0 faq-category-card">
          <Card.Body className="text-center p-4">
            <FontAwesomeIcon icon={faExchangeAlt} size="2x" className="text-success mb-3" />
            <Card.Title>Orders & Returns</Card.Title>
            <Card.Text className="text-muted">
              Details about placing orders, cancellations, and our return policy.
            </Card.Text>
          </Card.Body>
        </Card>
      </Col>
      <Col md={4} className="mb-4">
        <Card className="h-100 shadow-sm border-0 faq-category-card">
          <Card.Body className="text-center p-4">
            <FontAwesomeIcon icon={faLeaf} size="2x" className="text-success mb-3" />
            <Card.Title>Products</Card.Title>
            <Card.Text className="text-muted">
              Learn about our product quality, sourcing, and freshness guarantee.
            </Card.Text>
          </Card.Body>
        </Card>
      </Col>
    </Row>

    <Row>
      <Col lg={10} className="mx-auto">
        <Accordion defaultActiveKey="0" className="shadow-sm">
          <Accordion.Item eventKey="0">
            <Accordion.Header>
              <FontAwesomeIcon icon={faClock} className="me-2 text-success" />
              When will I get my groceries?
            </Accordion.Header>
            <Accordion.Body>
              <p className="mb-0">Usually within 24 hours. Our delivery team ensures fast and reliable service for your groceries. We offer several delivery windows:</p>
              <ul className="mt-2">
                <li>Morning delivery: 8 AM - 12 PM</li>
                <li>Afternoon delivery: 1 PM - 5 PM</li>
                <li>Evening delivery: 6 PM - 9 PM</li>
              </ul>
              <p>You can select your preferred delivery window during checkout.</p>
            </Accordion.Body>
          </Accordion.Item>
          
          <Accordion.Item eventKey="1">
            <Accordion.Header>
              <FontAwesomeIcon icon={faBan} className="me-2 text-success" />
              Can I cancel my order after placing it?
            </Accordion.Header>
            <Accordion.Body>
              Yes, you can cancel your order within an hour of placing it. After that, the order will be processed for delivery. To cancel an order:
              <ol className="mt-2">
                <li>Log into your account</li>
                <li>Go to "My Orders"</li>
                <li>Find the order you wish to cancel</li>
                <li>Click the "Cancel Order" button</li>
              </ol>
              <p className="mb-0">If you need to cancel after the one-hour window, please contact our customer support team.</p>
            </Accordion.Body>
          </Accordion.Item>
          
          <Accordion.Item eventKey="2">
            <Accordion.Header>
              <FontAwesomeIcon icon={faMapMarkerAlt} className="me-2 text-success" />
              Do you deliver to my area?
            </Accordion.Header>
            <Accordion.Body>
              We currently offer delivery in selected areas. You can check your eligibility by entering your delivery address at checkout. We're constantly expanding our delivery zones to serve more customers.
              <p className="mt-2">Our current service areas include:</p>
              <ul>
                <li>Downtown and surrounding neighborhoods</li>
                <li>Eastern and Western suburbs within 25 miles</li>
                <li>Selected rural areas (check eligibility with your zip code)</li>
              </ul>
            </Accordion.Body>
          </Accordion.Item>
          
          <Accordion.Item eventKey="3">
            <Accordion.Header>
              <FontAwesomeIcon icon={faCreditCard} className="me-2 text-success" />
              What payment methods do you accept?
            </Accordion.Header>
            <Accordion.Body>
              <p className="mb-2">We accept all major payment methods for your convenience:</p>
              <div className="row">
                <div className="col-md-6">
                  <ul>
                    <li>Credit cards (Visa, MasterCard, American Express, Discover)</li>
                    <li>Debit cards</li>
                    <li>Net banking</li>
                  </ul>
                </div>
                <div className="col-md-6">
                  <ul>
                    <li>Mobile wallets (Apple Pay, Google Pay)</li>
                    <li>PayPal</li>
                    <li>Gift cards and store credit</li>
                  </ul>
                </div>
              </div>
              <p className="mb-0">All payments are processed securely through our encrypted payment gateway.</p>
            </Accordion.Body>
          </Accordion.Item>
          
          <Accordion.Item eventKey="4">
            <Accordion.Header>
              <FontAwesomeIcon icon={faShippingFast} className="me-2 text-success" />
              How do I track my order?
            </Accordion.Header>
            <Accordion.Body>
              You can track your order status directly from the "My Orders" section in your account dashboard. Once your order is out for delivery, you'll receive real-time updates via email or SMS. Our delivery tracking system allows you to see the estimated arrival time and current status of your groceries.
            </Accordion.Body>
          </Accordion.Item>
          
          <Accordion.Item eventKey="5">
            <Accordion.Header>
              <FontAwesomeIcon icon={faShieldAlt} className="me-2 text-success" />
              What is your privacy policy?
            </Accordion.Header>
            <Accordion.Body>
              We take your privacy seriously. All personal information collected is used solely for processing your orders and improving your shopping experience. We never share your information with third parties for marketing purposes. For complete details, please review our Privacy Policy page.
            </Accordion.Body>
          </Accordion.Item>
          
          <Accordion.Item eventKey="6">
            <Accordion.Header>
              <FontAwesomeIcon icon={faUserPlus} className="me-2 text-success" />
              How do I create an account?
            </Accordion.Header>
            <Accordion.Body>
              Creating an account is simple and takes less than a minute:
              <ol className="mt-2">
                <li>Click on "Sign Up" in the top navigation</li>
                <li>Enter your email address and create a password</li>
                <li>Fill in your basic information and delivery address</li>
                <li>Verify your email address</li>
                <li>Start shopping!</li>
              </ol>
              <p className="mb-0">Having an account allows you to track orders, save favorite items, and check out faster.</p>
            </Accordion.Body>
          </Accordion.Item>
        </Accordion>
      </Col>
    </Row>
    
    <Row className="mt-5">
      <Col className="text-center">
        {/* <p className="mb-2">Still have questions?</p>
        <a href="/contact" className="btn btn-success px-4 py-2">Contact Our Support Team</a> */}
      </Col>
    </Row>
  </Container>
);

export default FAQ;
