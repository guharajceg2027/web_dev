import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Row, Col, Card, Button, Container, Form } from 'react-bootstrap';
import { useCart } from '../context/CartContext';
import './shopCategory.css';
import carrotImg from '../assets/carrot.webp';
import spinachImg from '../assets/spinach.webp'
import potatoImg from '../assets/potato.jpg';
import tomatoImg from '../assets/tomato.avif';
import cucumberImg from '../assets/cucumber.webp';
import onionImg from '../assets/onion.jpg';
import garlicImg from '../assets/garlic.webp';
import lettuceImg from '../assets/lettuce.webp';
import bellPepperImg from '../assets/bellPepper.jpeg';
import broccoliImg from '../assets/brocolli.webp';
import appleImg from '../assets/apple.webp';
import bananaImg from '../assets/banana.webp';
import orangeImg from '../assets/orange.webp';
import strawberryImg from '../assets/Strawberry.jpg';
import grapesImg from '../assets/grapes.jpg';
import pineappleImg from '../assets/pineapple.webp';
import watermelonImg from '../assets/watermelon.avif';
import blueberryImg from '../assets/blueberry.jpg';
import mangoImg from '../assets/mango.webp';
import peachImg from '../assets/peach.jpg';
import milkImg from '../assets/milk.avif';
import cheeseImg from '../assets/cheese.webp';
import butterImg from '../assets/butter.jpg';
import yogurtImg from '../assets/yogurt.jpg';
import creamImg from '../assets/cream.jpg';
import cottageCheeseImg from '../assets/cottagecheese.webp';
import mozzarellaImg from '../assets/mozarella.png';
import iceCreamImg from '../assets/icecream.jpg';
import sourCreamImg from '../assets/sourcream.jpg';
import milkPowderImg from '../assets/milkpowder.webp';
import chipsImg from '../assets/chips.jpg';
import cookiesImg from '../assets/cookies.jpg';
import popcornImg from '../assets/popcorn.webp';
import candyImg from '../assets/candy.webp';
import chocolateImg from '../assets/chocolate.jpeg';
import pretzelsImg from '../assets/pretzels.jpg';
import granolaBarImg from '../assets/granolabar.jpg';
import nutsImg from '../assets/nuts.webp';
import chewingGumImg from '../assets/chewinggum.jpg';
import biscuitsImg from '../assets/biscuit.jpg';
import juiceImg from '../assets/juice.png';
import sodaImg from '../assets/soda.jpg';
import coffeeImg from '../assets/coffee.jpg';
import teaImg from '../assets/tea.jpg';
import energyDrinkImg from '../assets/energydrink.jpg';
import waterImg from '../assets/water.jpg';
import milkshakeImg from '../assets/milkshake.jpg';
import smoothieImg from '../assets/smoothie.jpg';
import icedTeaImg from '../assets/icetea.jpg';
import lemonadeImg from '../assets/lemonade.jpg';
import breadImg from '../assets/bread.jpg';
import cakeImg from '../assets/cake.jpg';
import muffinImg from '../assets/muffin.jpg';
import pastryImg from '../assets/pastry.jpg';
import croissantImg from '../assets/crossiant.jpg';
import cookiesBakeryImg from '../assets/cookiess.jpg';
import donutsImg from '../assets/donuts.webp';
import browniesImg from '../assets/brownies.jpg';
import bagelImg from '../assets/bagel.png';
import pieImg from '../assets/pie.jpg';

const ShopCategory = () => {
  const { category } = useParams();
  const { addToCart } = useCart();
  const [searchTerm, setSearchTerm] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  
  // Replace single price range with min and max price
  const [minPrice, setMinPrice] = useState(0);
  const [maxPrice, setMaxPrice] = useState(400);
  
  // Step 1: Add state for success message
  const products = {
    Vegetables: [
      { name: "Carrot", price: "₹150", image: carrotImg, weight: "500g" },
      { name: "Spinach", price: "₹200", image: spinachImg, weight: "250g" },
      { name: "Potato", price: "₹100", image: potatoImg, weight: "1kg" },
      { name: "Tomato", price: "₹180", image: tomatoImg, weight: "500g" },
      { name: "Cucumber", price: "₹120", image: cucumberImg, weight: "400g" },
      { name: "Onion", price: "₹130", image: onionImg, weight: "500g" },
      { name: "Garlic", price: "₹150", image: garlicImg, weight: "250g" },
      { name: "Lettuce", price: "₹200", image: lettuceImg, weight: "200g" },
      { name: "Bell Pepper", price: "₹220", image: bellPepperImg, weight: "300g" },
      { name: "Broccoli", price: "₹250", image: broccoliImg, weight: "400g" },
    ],
    Fruits:[
      { name: "Apple", price: "₹80", image: appleImg, weight: "500g" },
      { name: "Banana", price: "₹40", image: bananaImg, weight: "1kg" },
      { name: "Orange", price: "₹100", image: orangeImg, weight: "600g" },
      { name: "Strawberry", price: "₹250", image: strawberryImg, weight: "250g" },
      { name: "Grapes", price: "₹180", image: grapesImg, weight: "500g" },
      { name: "Pineapple", price: "₹200", image: pineappleImg, weight: "1kg" },
      { name: "Watermelon", price: "₹300", image: watermelonImg, weight: "2kg" },
      { name: "Blueberry", price: "₹350", image: blueberryImg, weight: "200g" },
      { name: "Mango", price: "₹150", image: mangoImg, weight: "500g" },
      { name: "Peach", price: "₹220", image: peachImg, weight: "400g" }
    ],
    Dairy: [
      { name: "Milk", price: "₹60", image: milkImg, weight: "1L" },
      { name: "Cheese", price: "₹300", image: cheeseImg, weight: "200g" },
      { name: "Butter", price: "₹180", image: butterImg, weight: "100g" },
      { name: "Yogurt", price: "₹100", image: yogurtImg, weight: "400g" },
      { name: "Cream", price: "₹120", image: creamImg, weight: "200g" },
      { name: "Cottage Cheese", price: "₹250", image: cottageCheeseImg, weight: "250g" },
      { name: "Mozzarella", price: "₹350", image: mozzarellaImg, weight: "200g" },
      { name: "Ice Cream", price: "₹300", image: iceCreamImg, weight: "500g" },
      { name: "Sour Cream", price: "₹150", image: sourCreamImg, weight: "200g" },
      { name: "Milk Powder", price: "₹200", image: milkPowderImg, weight: "500g" }],
    Snacks: [
      { name: "Chips", price: "₹50", image: chipsImg, weight: "200g" },
  { name: "Cookies", price: "₹150", image: cookiesImg, weight: "150g" },
  { name: "Popcorn", price: "₹80", image: popcornImg, weight: "100g" },
  { name: "Candy", price: "₹30", image: candyImg, weight: "150g" },
  { name: "Chocolate", price: "₹200", image: chocolateImg, weight: "100g" },
  { name: "Pretzels", price: "₹120", image: pretzelsImg, weight: "200g" },
  { name: "Granola Bar", price: "₹150", image: granolaBarImg, weight: "100g" },
  { name: "Nuts", price: "₹250", image: nutsImg, weight: "300g" },
  { name: "Chewing Gum", price: "₹40", image: chewingGumImg, weight: "50g" },
  { name: "Biscuits", price: "₹100", image: biscuitsImg, weight: "200g" }
  ],
    Beverages: [
      { name: "Juice", price: "₹120", image: juiceImg, weight: "500ml" },
      { name: "Soda", price: "₹50", image: sodaImg, weight: "500ml" },
      { name: "Coffee", price: "₹150", image: coffeeImg, weight: "250g" },
      { name: "Tea", price: "₹80", image: teaImg, weight: "100g" },
      { name: "Energy Drink", price: "₹250", image: energyDrinkImg, weight: "250ml" },
      { name: "Water", price: "₹20", image: waterImg, weight: "1L" },
      { name: "Milkshake", price: "₹200", image: milkshakeImg, weight: "500ml" },
      { name: "Smoothie", price: "₹300", image: smoothieImg, weight: "500ml" },
      { name: "Iced Tea", price: "₹120", image: icedTeaImg, weight: "300ml" },
      { name: "Lemonade", price: "₹100", image: lemonadeImg, weight: "400ml" }
     ],
    Bakery: [
      { name: "Bread", price: "₹60", image: breadImg, weight: "400g" },
  { name: "Cake", price: "₹300", image: cakeImg, weight: "500g" },
  { name: "Muffin", price: "₹120", image: muffinImg, weight: "150g" },
  { name: "Pastry", price: "₹180", image: pastryImg, weight: "100g" },
  { name: "Croissant", price: "₹150", image: croissantImg, weight: "100g" },
  { name: "Cookies", price: "₹80", image: cookiesBakeryImg, weight: "150g" },
  { name: "Donuts", price: "₹120", image: donutsImg, weight: "200g" },
  { name: "Brownies", price: "₹200", image: browniesImg, weight: "250g" },
  { name: "Bagel", price: "₹100", image: bagelImg, weight: "150g" },
  { name: "Pie", price: "₹250", image: pieImg, weight: "400g" }]
  };

  // Safely get products for the current category
  const categoryProducts = products[category] || [];
  
  // Helper function to extract numeric price value
  const extractPrice = (priceString) => {
    return parseInt(priceString.replace(/[^\d]/g, ''), 10);
  };

  // Find max price in current category for slider max value
  const maxCategoryPrice = categoryProducts.length > 0 
    ? Math.max(...categoryProducts.map(product => extractPrice(product.price)))
    : 400;
    
  // Set initial max price when category changes
  React.useEffect(() => {
    setMaxPrice(maxCategoryPrice);
  }, [category, maxCategoryPrice]);

  // Filter products by search term and price range
  const filteredProducts = categoryProducts.filter((product) => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase());
    const productPrice = extractPrice(product.price);
    const matchesPrice = productPrice >= minPrice && productPrice <= maxPrice;
    return matchesSearch && matchesPrice;
  });

  // Step 2: Add to cart and show success message
  const handleAddToCart = (product) => {
    addToCart(product);
    setSuccessMessage(`${product.name} added to cart!`);  // Show success message
    setTimeout(() => {
      setSuccessMessage("");  // Hide success message after 3 seconds
    }, 3000);
  };

  // Handle min price change
  const handleMinPriceChange = (e) => {
    const value = parseInt(e.target.value);
    setMinPrice(value > maxPrice ? maxPrice : value);
  };

  // Handle max price change
  const handleMaxPriceChange = (e) => {
    const value = parseInt(e.target.value);
    setMaxPrice(value < minPrice ? minPrice : value);
  };

  return (
    <Container className="py-4">
      <div className="heading-bg-container py-4 text-center">
        <h2 className="styled-heading fw-bold fs-1">Shop by Category</h2>
      </div>
      {/* Category Name */}
      <div className="category-name-container py-3 text-center">
        <h3 className="category-name">{category.charAt(0).toUpperCase() + category.slice(1)}</h3>
      </div>
      
      {/* Filters Section */}
      <div className="filters-container mb-4">
        <Row>
          {/* 🔍 Search Bar */}
          <Col md={6} className="mb-3">
            <Form.Group controlId="searchBar" className="position-relative">
              <Form.Control
                type="text"
                placeholder={`🔍 Search ${category.toLowerCase()}...`}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="form-control-lg rounded-pill shadow-sm border border-success search-bar"
              />
            </Form.Group>
          </Col>
          
          {/* Price Range Filter - Updated to min/max inputs */}
          <Col md={6} className="mb-3">
            <div className="price-filter-container p-3 border rounded shadow-sm">
              <h5 className="mb-3">Price Range: ₹{minPrice} - ₹{maxPrice}</h5>
              
              <Row className="mb-3">
                <Col>
                  <Form.Label>Min Price</Form.Label>
                  <Form.Control 
                    type="number" 
                    min="0" 
                    max={maxCategoryPrice} 
                    value={minPrice}
                    onChange={handleMinPriceChange}
                    className="form-control-sm"
                  />
                </Col>
                <Col>
                  <Form.Label>Max Price</Form.Label>
                  <Form.Control 
                    type="number" 
                    min="0" 
                    max={maxCategoryPrice} 
                    value={maxPrice}
                    onChange={handleMaxPriceChange}
                    className="form-control-sm"
                  />
                </Col>
              </Row>
              
              <div className="d-flex justify-content-between align-items-center">
                <Form.Range
                  min={0}
                  max={maxCategoryPrice}
                  value={minPrice}
                  onChange={handleMinPriceChange}
                  className="price-slider me-2"
                />
                <Form.Range
                  min={0}
                  max={maxCategoryPrice}
                  value={maxPrice}
                  onChange={handleMaxPriceChange}
                  className="price-slider"
                />
              </div>
              
              <div className="d-flex justify-content-between mt-2">
                <span>₹0</span>
                <span>₹{maxCategoryPrice}</span>
              </div>
            </div>
          </Col>
        </Row>
      </div>
      
      {/* Success Message */}
      {successMessage && (
        <div className="alert alert-success text-center" role="alert">
          {successMessage}
        </div>
      )}
      
      {/* Products Grid */}
      <Row>
      {filteredProducts.length > 0 ? (
          filteredProducts.map((product, index) => (
            <Col key={index} xs={12} sm={6} md={4} lg={3} className="mb-4">
              <Card className="h-100 text-center shadow-sm">
                <div style={{ width: "100%", height: "200px", overflow: "hidden" }}>
                  <Card.Img
                    variant="top"
                    src={product.image}
                    alt={product.name}
                    style={{ objectFit: "cover", width: "100%", height: "100%" }}
                  />
                </div>
                <Card.Body className="d-flex flex-column justify-content-between">
                  <div>
                    <Card.Title>{product.name}</Card.Title>
                    <Card.Text>
                      <strong>{product.price}</strong> <br />
                      <small>{product.weight}</small>
                    </Card.Text>
                  </div>
                  <Button
                    variant="success"
                    onClick={() => handleAddToCart(product)} // Step 3: Use handleAddToCart
                    className="mt-2"
                  >
                    Add to Cart
                  </Button>
                </Card.Body>
              </Card>
            </Col>
          ))
        ) : (
          <Col>
            <p className="text-center">No matching items found. Try adjusting your filters.</p>
          </Col>
        )}
      </Row>
    </Container>
  );
};

export default ShopCategory;
