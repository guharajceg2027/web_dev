import React from 'react';
import { Container, Card, Row, Col, Accordion, Badge } from 'react-bootstrap';
import { FaShieldAlt, FaFileContract, FaTruck, FaUndo, FaExclamationTriangle, FaLock, FaEdit } from 'react-icons/fa';
import './Page.css';

const TermsAndConditions = () => {
  // Last updated date
  const lastUpdated = "November 15, 2023";
  
  return (
    <Container className="page py-5" style={{ maxWidth: '900px', margin: '0 auto' }}>
      <Card className="border-0 shadow-lg mb-5">
        <Card.Header className="bg-primary text-white text-center py-4">
          <h1 className="fw-bold mb-0">Terms and Conditions</h1>
          <p className="mb-0 mt-2">Last Updated: {lastUpdated}</p>
        </Card.Header>
        
        <Card.Body className="p-4 p-md-5">
          <div className="alert alert-info mb-4" role="alert">
            <div className="d-flex align-items-center">
              <FaShieldAlt className="me-2" size={20} />
              <div>
                <strong>Important:</strong> By using GroceryCart, you agree to these terms and conditions. 
                Please read them carefully as they govern your use of our services.
              </div>
            </div>
          </div>
          
          <section className="mb-4">
            <h2 className="border-bottom pb-2 mb-4">Overview</h2>
            <p className="lead">
              Welcome to GroceryCart! These Terms and Conditions constitute a legally binding agreement made between you and GroceryCart, 
              concerning your access to and use of our website and services.
            </p>
            <p>
              By creating an account or using any part of our platform, you acknowledge that you have read, understood, and agree to be bound by these Terms. 
              If you do not agree with all of these terms, you are prohibited from using the service and should discontinue use immediately.
            </p>
          </section>
          
          <Accordion className="mb-4">
            <Accordion.Item eventKey="0">
              <Accordion.Header>
                <div className="d-flex align-items-center">
                  <FaFileContract className="me-2 text-primary" />
                  <strong>1. Introduction</strong>
                </div>
              </Accordion.Header>
              <Accordion.Body>
                <p>
                  Welcome to GroceryCart! By using our platform, you agree to comply with and be bound by these terms of service.
                  If you do not agree with these terms, please refrain from using our services.
                </p>
                <p>
                  Our platform provides an online marketplace for grocery shopping and delivery services. We strive to ensure
                  a seamless shopping experience with high-quality products and reliable delivery.
                </p>
                <p>
                  These terms apply to all users, visitors, and others who access or use the GroceryCart service.
                </p>
              </Accordion.Body>
            </Accordion.Item>
            
            <Accordion.Item eventKey="1">
              <Accordion.Header>
                <div className="d-flex align-items-center">
                  <FaShieldAlt className="me-2 text-primary" />
                  <strong>2. User Responsibilities</strong>
                </div>
              </Accordion.Header>
              <Accordion.Body>
                <p>
                  Users are responsible for maintaining the confidentiality of their account information, including login credentials.
                  You agree to notify us immediately of any unauthorized use of your account.
                </p>
                <p>
                  You are responsible for providing accurate and complete information when creating an account and placing orders.
                  Inaccurate information may result in delivery delays or cancellations.
                </p>
                <p>
                  Users must be at least 18 years old to create an account and use our services. By creating an account,
                  you confirm that you are at least 18 years of age.
                </p>
              </Accordion.Body>
            </Accordion.Item>
            
            <Accordion.Item eventKey="2">
              <Accordion.Header>
                <div className="d-flex align-items-center">
                  <FaTruck className="me-2 text-primary" />
                  <strong>3. Delivery Policy</strong>
                </div>
              </Accordion.Header>
              <Accordion.Body>
                <p>
                  We aim to deliver your groceries within 24 hours of order confirmation. However, delivery times may vary depending on location.
                </p>
                <p>
                  Delivery schedules are subject to availability and may be affected by factors beyond our control, such as weather conditions,
                  traffic, or high demand periods.
                </p>
                <p>
                  You agree to provide accurate delivery information and ensure that someone is available to receive the order during the selected delivery window.
                  If no one is available to receive the order, we may leave it at a safe location or return it to our facility, at our discretion.
                </p>
              </Accordion.Body>
            </Accordion.Item>
            
            <Accordion.Item eventKey="3">
              <Accordion.Header>
                <div className="d-flex align-items-center">
                  <FaUndo className="me-2 text-primary" />
                  <strong>4. Refund and Cancellation</strong>
                </div>
              </Accordion.Header>
              <Accordion.Body>
                <p>
                  You can cancel your order within an hour of placing it. After that, the order will be processed, and cancellation may not be possible.
                </p>
                <p>
                  If you receive damaged or spoiled products, you may request a refund within 24 hours of delivery by contacting our customer service team.
                  Please provide photos of the affected items to expedite the refund process.
                </p>
                <p>
                  Refunds will be processed within 3-5 business days and will be issued to the original payment method used for the purchase.
                </p>
              </Accordion.Body>
            </Accordion.Item>
            
            <Accordion.Item eventKey="4">
              <Accordion.Header>
                <div className="d-flex align-items-center">
                  <FaExclamationTriangle className="me-2 text-primary" />
                  <strong>5. Limitation of Liability</strong>
                </div>
              </Accordion.Header>
              <Accordion.Body>
                <p>
                  We are not liable for any indirect, incidental, or consequential damages arising from the use of our services.
                </p>
                <p>
                  Our liability is limited to the amount paid by you for the specific order in question. We are not responsible for any
                  damages or losses resulting from your failure to comply with these terms.
                </p>
                <p>
                  We do not guarantee the availability of all products at all times. Product availability is subject to change without notice.
                </p>
              </Accordion.Body>
            </Accordion.Item>
            
            <Accordion.Item eventKey="5">
              <Accordion.Header>
                <div className="d-flex align-items-center">
                  <FaLock className="me-2 text-primary" />
                  <strong>6. Privacy Policy</strong>
                </div>
              </Accordion.Header>
              <Accordion.Body>
                <p>
                  Your privacy is important to us. We collect only the necessary information to provide and improve our services.
                </p>
                <p>
                  We may collect personal information such as your name, email address, phone number, and delivery address to process your orders
                  and provide customer support.
                </p>
                <p>
                  We do not sell or share your personal information with third parties except as necessary to provide our services
                  (such as with delivery partners) or as required by law.
                </p>
                <p>
                  For more details, please refer to our <Badge bg="primary" className="cursor-pointer">Privacy Policy</Badge>.
                </p>
              </Accordion.Body>
            </Accordion.Item>
            
            <Accordion.Item eventKey="6">
              <Accordion.Header>
                <div className="d-flex align-items-center">
                  <FaEdit className="me-2 text-primary" />
                  <strong>7. Amendments</strong>
                </div>
              </Accordion.Header>
              <Accordion.Body>
                <p>
                  We reserve the right to modify or amend these terms at any time. Any changes will be effective immediately upon posting.
                </p>
                <p>
                  We will make reasonable efforts to notify users of significant changes to these terms, but it is your responsibility
                  to review these terms periodically to stay informed of any updates.
                </p>
                <p>
                  Your continued use of our services after any modifications to the terms constitutes your acceptance of the revised terms.
                </p>
              </Accordion.Body>
            </Accordion.Item>
          </Accordion>
          
          <section className="mt-5">
            <Row>
              <Col md={6}>
                <Card className="h-100 border-0 shadow-sm">
                  <Card.Body className="p-4">
                    <h4 className="fw-bold mb-3">Contact Us</h4>
                    <p>
                      If you have any questions about these Terms and Conditions, please contact us:
                    </p>
                    <ul className="list-unstyled">
                      <li><strong>Email:</strong> support@grocerycart.com</li>
                      <li><strong>Phone:</strong> (555) 123-4567</li>
                      <li><strong>Address:</strong> 123 Grocery Lane, Fresh City, FC 12345</li>
                    </ul>
                  </Card.Body>
                </Card>
              </Col>
              <Col md={6}>
                <Card className="h-100 border-0 shadow-sm">
                  <Card.Body className="p-4">
                    <h4 className="fw-bold mb-3">Legal Information</h4>
                    <p>
                      GroceryCart is a registered business operating under the laws of [Your Country/State].
                    </p>
                    <p>
                      Business Registration Number: GC-12345678
                    </p>
                    <p>
                      © {new Date().getFullYear()} GroceryCart. All rights reserved.
                    </p>
                  </Card.Body>
                </Card>
              </Col>
            </Row>
          </section>
        </Card.Body>
      </Card>
    </Container>
  );
};

export default TermsAndConditions;
