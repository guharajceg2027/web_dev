import React from 'react';
import { Container, Row, Col, Card } from 'react-bootstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
  faShieldAlt, 
  faUserLock, 
  faDatabase, 
  faLock, 
  faShareAlt, 
  faCookieBite, 
  faUserEdit, 
  faHistory,
  faInfoCircle
} from '@fortawesome/free-solid-svg-icons';
import './Page.css';

const PrivacyPolicy = () => (
  <Container className="page py-5" style={{ maxWidth: '900px', margin: '0 auto' }}>
    <Row className="mb-5">
      <Col className="text-center">
        <FontAwesomeIcon icon={faShieldAlt} size="3x" className="text-success mb-3" />
        <h2 className="fw-bold text-success">Privacy Policy</h2>
        <p className="text-muted">Last Updated: June 15, 2023</p>
      </Col>
    </Row>

    <Card className="shadow-sm mb-4 border-0">
      <Card.Body className="p-4">
        <div className="alert alert-success bg-light border-success border-start border-4 mb-4">
          <FontAwesomeIcon icon={faInfoCircle} className="me-2 text-success" />
          <span className="fw-medium">Your privacy is important to us.</span> This Privacy Policy explains the personal data we collect and how we use it. By using this site, you agree to the practices described in this policy.
        </div>
        
        <div className="policy-section">
          <div className="d-flex align-items-center mb-3">
            <div className="icon-circle bg-success-subtle me-3">
              <FontAwesomeIcon icon={faUserLock} className="text-success" />
            </div>
            <h4 className="fw-bold mb-0">1. Information We Collect</h4>
          </div>
          <p className="ms-5">
            We collect personal information that you provide when creating an account, placing an order, or contacting our customer service team. This includes:
          </p>
          <ul className="ms-5">
            <li>Name and contact details (email address, phone number)</li>
            <li>Delivery address and billing information</li>
            <li>Payment information (processed securely through our payment providers)</li>
            <li>Order history and preferences</li>
            <li>Communications with our customer service team</li>
          </ul>
        </div>
        
        <div className="policy-section mt-4">
          <div className="d-flex align-items-center mb-3">
            <div className="icon-circle bg-success-subtle me-3">
              <FontAwesomeIcon icon={faDatabase} className="text-success" />
            </div>
            <h4 className="fw-bold mb-0">2. How We Use Your Information</h4>
          </div>
          <p className="ms-5">
            The personal information we collect is used to:
          </p>
          <ul className="ms-5">
            <li>Process and fulfill your orders</li>
            <li>Provide customer support and respond to inquiries</li>
            <li>Improve our services and website functionality</li>
            <li>Send order confirmations and delivery updates</li>
            <li>Send promotional emails about new products or special offers (with your consent)</li>
          </ul>
          <p className="ms-5">
            You can opt out of marketing communications at any time by clicking the "unsubscribe" link in our emails or contacting customer service.
          </p>
        </div>
        
        <div className="policy-section mt-4">
          <div className="d-flex align-items-center mb-3">
            <div className="icon-circle bg-success-subtle me-3">
              <FontAwesomeIcon icon={faLock} className="text-success" />
            </div>
            <h4 className="fw-bold mb-0">3. Data Protection</h4>
          </div>
          <p className="ms-5">
            We take your privacy seriously and implement appropriate security measures to protect your data from unauthorized access, alteration, or destruction. These measures include:
          </p>
          <ul className="ms-5">
            <li>Encryption of sensitive data</li>
            <li>Secure payment processing</li>
            <li>Regular security assessments</li>
            <li>Employee training on data protection</li>
            <li>Limited access to personal information on a need-to-know basis</li>
          </ul>
        </div>
        
        <div className="policy-section mt-4">
          <div className="d-flex align-items-center mb-3">
            <div className="icon-circle bg-success-subtle me-3">
              <FontAwesomeIcon icon={faShareAlt} className="text-success" />
            </div>
            <h4 className="fw-bold mb-0">4. Sharing Your Data</h4>
          </div>
          <p className="ms-5">
            We do not sell, rent, or share your personal data with third parties for their marketing purposes. However, we may share data with:
          </p>
          <ul className="ms-5">
            <li>Service providers who help us run our business (e.g., payment processors, delivery services)</li>
            <li>Legal authorities when required by law</li>
            <li>Professional advisors (e.g., lawyers, accountants, auditors)</li>
          </ul>
          <p className="ms-5">
            All third-party service providers are contractually obligated to use your data only for the purposes specified by us and in accordance with this privacy policy.
          </p>
        </div>
        
        <div className="policy-section mt-4">
          <div className="d-flex align-items-center mb-3">
            <div className="icon-circle bg-success-subtle me-3">
              <FontAwesomeIcon icon={faCookieBite} className="text-success" />
            </div>
            <h4 className="fw-bold mb-0">5. Cookies</h4>
          </div>
          <p className="ms-5">
            Our website uses cookies to enhance user experience. These cookies help us:
          </p>
          <ul className="ms-5">
            <li>Remember your login details</li>
            <li>Understand how you use our website</li>
            <li>Personalize your shopping experience</li>
            <li>Improve our website functionality</li>
          </ul>
          <p className="ms-5">
            By using our site, you consent to the use of cookies. You can manage cookie preferences through your browser settings.
          </p>
        </div>
        
        <div className="policy-section mt-4">
          <div className="d-flex align-items-center mb-3">
            <div className="icon-circle bg-success-subtle me-3">
              <FontAwesomeIcon icon={faUserEdit} className="text-success" />
            </div>
            <h4 className="fw-bold mb-0">6. Your Rights</h4>
          </div>
          <p className="ms-5">
            Under applicable data protection laws, you have the right to:
          </p>
          <ul className="ms-5">
            <li>Access your personal data</li>
            <li>Correct inaccurate or incomplete data</li>
            <li>Request deletion of your data</li>
            <li>Restrict or object to certain processing of your data</li>
            <li>Request a copy of your data in a structured, machine-readable format</li>
          </ul>
          <p className="ms-5">
            To exercise any of these rights, please contact our customer service team at privacy@grocerycart.com.
          </p>
        </div>
        
        <div className="policy-section mt-4">
          <div className="d-flex align-items-center mb-3">
            <div className="icon-circle bg-success-subtle me-3">
              <FontAwesomeIcon icon={faHistory} className="text-success" />
            </div>
            <h4 className="fw-bold mb-0">7. Changes to This Policy</h4>
          </div>
          <p className="ms-5">
            We may update this privacy policy from time to time to reflect changes in our practices or for legal, operational, or regulatory reasons. Any changes will be posted on this page, and the date of the most recent revision will be updated at the top of the policy.
          </p>
          <p className="ms-5">
            We encourage you to review this policy periodically to stay informed about how we protect your personal information.
          </p>
        </div>
      </Card.Body>
    </Card>
    
    <Row className="mt-5">
      <Col className="text-center">
        <div className="border-top pt-4">
          <p className="mb-3">
            Thank you for trusting GroceryCart with your personal information. If you have any questions about this Privacy Policy, please contact us at:
          </p>
          <p className="fw-medium">
            <FontAwesomeIcon icon={faInfoCircle} className="me-2 text-success" />
            privacy@grocerycart.com
          </p>
          {/* <a href="/contact" className="btn btn-outline-success mt-2">Contact Our Privacy Team</a> */}
        </div>
      </Col>
    </Row>
  </Container>
);

export default PrivacyPolicy;
