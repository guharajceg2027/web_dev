import React from 'react';
import '@fontsource/poppins';
import './Home.css';
import { Carousel, Container, Row, Col, Card} from 'react-bootstrap';
import 'bootstrap-icons/font/bootstrap-icons.css'; 
import '@fontsource/montserrat/800.css'; // Import the 800 weight
//import { useNavigate } from 'react-router-dom';
import vegetablesImg from '../assets/fresh.webp';
import fruitsImg from '../assets/tasty.avif';
import essentialsImg from '../assets/daily.jpg';
import avatar1 from '../assets/testimonal1.jpg';
import avatar2 from '../assets/testimonal2.webp';
import avatar3 from '../assets/testimonal3.avif';
import fruitsImgs from '../assets/fruits.webp';
import vegetablesImgs from '../assets/veg.avif';

const testimonials = [
  {
     name: "Sarah Johnson",
     text: "I love the fast delivery and fresh products! Highly recommend GroceryCart!",
     rating: 5,
    image: avatar1
  },
  {
     name: "Michael Brown",
     text: "The quality of fruits and vegetables is exceptional. Everything is always fresh!",
     rating: 4.5,
    image: avatar2
  },
  {
     name: "Emily Davis",
     text: "Customer service is outstanding. They always go above and beyond to help!",
     rating: 5,
    image: avatar3
  }
];

const Home = () => {
  //const navigate = useNavigate();

  // Helper function to render stars
  const renderStars = (rating) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<i key={`star-${i}`} className="bi bi-star-fill text-warning"></i>);
    }
    
    if (hasHalfStar) {
      stars.push(<i key="half-star" className="bi bi-star-half text-warning"></i>);
    }
    
    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<i key={`empty-${i}`} className="bi bi-star text-warning"></i>);
    }
    
    return stars;
  };

  return (
    <div className="home-page">
      {/* Hero Section */}
      {/* Hero Section */}
<section className="hero-section position-relative">
  {/* Stylish message banner positioned above carousel */}
  <div 
    className="text-center py-4 w-100" 
    style={{ 
      background: 'linear-gradient(135deg, #28a745, #17a2b8)',
      position: 'relative',
      zIndex: 10,
      boxShadow: '0 4px 15px rgba(0,0,0,0.1)'
    }}
  >
    <Container>
      <p 
        className="mb-0 animate__animated animate__fadeInDown"
        style={{
          fontFamily: "'Montserrat', sans-serif",
          fontWeight: 800,
          fontSize: '2.5rem',
          letterSpacing: '1px',
          color: 'white',
          textShadow: '2px 2px 4px rgba(0,0,0,0.2)',
          textTransform: 'uppercase'
        }}
      >
        <span style={{ color: '#FFD700' }}>Fresh</span> & <span style={{ color: '#FFD700' }}>Fast</span> Groceries
      </p>
      <p
        className="mb-0 mt-2 animate__animated animate__fadeInUp animate__delay-1s"
        style={{
          fontFamily: "'Poppins', sans-serif",
          fontWeight: 300,
          fontSize: '1.2rem',
          color: 'white',
          letterSpacing: '0.5px'
        }}
      >
        Quality products delivered to your doorstep
      </p>
    </Container>
  </div>
  
  {/* Carousel */}
  <Carousel className="carousel-custom" interval={5000} fade>
    <Carousel.Item>
      <div className="carousel-image-container">
        <img
          className="d-block w-100 carousel-image"
          src={vegetablesImgs}
          alt="Fresh Vegetables"
        />
      </div>
      <Carousel.Caption className="carousel-caption-custom">
        <h2 className="display-4 fw-bold text-shadow">Fresh Vegetables</h2>
        <p className="carousel-text fs-5 fw-semibold text-shadow">Farm-fresh veggies delivered to your door.</p>
      </Carousel.Caption>
    </Carousel.Item>
    <Carousel.Item>
      <div className="carousel-image-container">
        <img
          className="d-block w-100 carousel-image"
          src={fruitsImgs}
          alt="Tasty Fruits"
        />
      </div>
      <Carousel.Caption className="carousel-caption-custom">
        <h2 className="display-4 fw-bold text-shadow">Tasty Fruits</h2>
        <p className="carousel-text fs-5 fw-semibold text-shadow">Enjoy juicy organic fruits every day.</p>
      </Carousel.Caption>
    </Carousel.Item>
    <Carousel.Item>
      <div className="carousel-image-container">
        <img
          className="d-block w-100 carousel-image"
          src={essentialsImg}
          alt="Daily Essentials"
        />
      </div>
      <Carousel.Caption className="carousel-caption-custom">
        <h2 className="display-4 fw-bold text-shadow">Daily Essentials</h2>
        <p className="carousel-text fs-5 fw-semibold text-shadow">Everything you need in one place.</p>
      </Carousel.Caption>
    </Carousel.Item>
  </Carousel>
</section>


      {/* Features Section */}
      <section className="features-section py-5 bg-light">
        <Container>
          <h2 className="text-center mb-5 section-title">Why Choose Us</h2>
          <Row className="g-4">
            <Col md={4}>
              <div className="feature-card text-center p-4 h-100 shadow-sm rounded">
                <div className="feature-icon mb-3">
                  <i className="bi bi-truck text-success display-4"></i>
                </div>
                <h3>Fast Delivery</h3>
                <p>Get your groceries delivered within hours of ordering.</p>
              </div>
            </Col>
            <Col md={4}>
              <div className="feature-card text-center p-4 h-100 shadow-sm rounded">
                <div className="feature-icon mb-3">
                  <i className="bi bi-award text-success display-4"></i>
                </div>
                <h3>Quality Products</h3>
                <p>We source only the freshest and highest quality products.</p>
              </div>
            </Col>
            <Col md={4}>
              <div className="feature-card text-center p-4 h-100 shadow-sm rounded">
                <div className="feature-icon mb-3">
                  <i className="bi bi-shield-check text-success display-4"></i>
                </div>
                <h3>Secure Payments</h3>
                <p>Multiple secure payment options for your convenience.</p>
              </div>
            </Col>
          </Row>
        </Container>
      </section>

      {/* Categories Showcase */}
      <section className="categories-section py-5">
        <Container>
          <h2 className="text-center mb-5 section-title">Shop By Category</h2>
          <Row className="g-4">
            <Col md={4}>
              <div className="category-card position-relative overflow-hidden rounded shadow">
                <img src={vegetablesImg} alt="Vegetables" className="img-fluid category-img" />
                <div className="category-overlay d-flex align-items-center justify-content-center">
                  <div className="text-center">
                    <h3 className="text-white mb-3">Vegetables</h3>
                    {/* Shop Now button removed */}
                  </div>
                </div>
              </div>
            </Col>
            <Col md={4}>
              <div className="category-card position-relative overflow-hidden rounded shadow">
                <img src={fruitsImg} alt="Fruits" className="img-fluid category-img" />
                <div className="category-overlay d-flex align-items-center justify-content-center">
                  <div className="text-center">
                    <h3 className="text-white mb-3">Fruits</h3>
                    {/* Shop Now button removed */}
                  </div>
                </div>
              </div>
            </Col>
            <Col md={4}>
              <div className="category-card position-relative overflow-hidden rounded shadow">
                <img src={essentialsImg} alt="Daily Essentials" className="img-fluid category-img" />
                <div className="category-overlay d-flex align-items-center justify-content-center">
                  <div className="text-center">
                    <h3 className="text-white mb-3">Daily Essentials</h3>
                    {/* Shop Now button removed */}
                  </div>
                </div>
              </div>
            </Col>
          </Row>
        </Container>
      </section>

      {/* Testimonials */}
      <section className="testimonial-section py-5 bg-light">
        <Container>
          <h2 className="text-center mb-5 section-title">What Our Customers Say</h2>
          <Row className="g-4">
            {testimonials.map((testimonial, index) => (
              <Col md={4} key={index}>
                <Card className="testimonial-card h-100 shadow-sm border-0">
                  <div className="testimonial-img-container mx-auto mt-4">
                    <img 
                      src={testimonial.image} 
                      alt={testimonial.name} 
                      className="testimonial-image rounded-circle"
                    />
                  </div>
                  <Card.Body className="text-center">
                    <div className="testimonial-stars mb-3">
                      {renderStars(testimonial.rating)}
                    </div>
                    <Card.Text className="fst-italic">
                      "{testimonial.text}"
                    </Card.Text>
                    <footer className="blockquote-footer mt-3">
                      <cite title="Source Title">{testimonial.name}</cite>
                    </footer>
                  </Card.Body>
                </Card>
              </Col>
            ))}
          </Row>
        </Container>
      </section>
      {/* Call to Action */}
    </div>
  );
};

export default Home;
