import React, { useState, useEffect } from "react";
import { useCart } from "../context/CartContext";
import { Card, Row, Col, Button, Form } from "react-bootstrap";
import './order.css';

const Cart = () => {
  const { cartItems, removeFromCart, clearCart } = useCart();
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [address, setAddress] = useState("");
  const [orderHistory, setOrderHistory] = useState([]);
  
  // Calculate subtotal before discount
  const subtotal = cartItems.reduce(
    (sum, item) => sum + item.quantity * parseInt(item.price.replace("₹", "")),
    0
  );
  
  // Discount tiers
  const discountTiers = [
    { threshold: 5000, percentage: 10 },
    { threshold: 3000, percentage: 5 },
    { threshold: 1000, percentage: 2 },
  ];
  
  // Calculate discount
  const getDiscount = (amount) => {
    for (const tier of discountTiers) {
      if (amount >= tier.threshold) {
        return {
          percentage: tier.percentage,
          amount: (amount * tier.percentage) / 100
        };
      }
    }
    return { percentage: 0, amount: 0 };
  };
  
  const discount = getDiscount(subtotal);
  const total = subtotal - discount.amount;

  // Fetch order history from localStorage on load
  useEffect(() => {
    const savedOrderHistory = JSON.parse(localStorage.getItem("orderHistory")) || [];
    setOrderHistory(savedOrderHistory);
  }, []);

  const handlePayment = () => {
    if (!address.trim()) {
      alert("Please enter a delivery address before proceeding.");
      return;
    }
    const order = {
      items: cartItems,
      subtotal: subtotal,
      discount: discount,
      total: total,
      date: new Date().toLocaleString(),
      address: address,
    };
    // Save order to order history
    const updatedOrderHistory = [...orderHistory, order];
    setOrderHistory(updatedOrderHistory);
    localStorage.setItem("orderHistory", JSON.stringify(updatedOrderHistory));
    setPaymentSuccess(true);
    clearCart();
  };

  return (
    <div className="cart-page p-4">
      <h2>Your Cart</h2>
      {cartItems.length === 0 && !paymentSuccess && (
        <p className="text-muted">🛒 Your cart is empty.</p>
      )}
      <Row>
        {cartItems.map((item, index) => (
          <Col md={6} lg={4} key={index} className="mb-4">
            <Card>
              <Card.Img
                variant="top"
                src={item.image}
                className="img-fluid"
                style={{
                  width: "150px",
                  height: "150px",
                  objectFit: "cover",
                  margin: "0 auto",
                }}
              />
              <Card.Body>
                <Card.Title>{item.name}</Card.Title>
                <Card.Text>Price: {item.price}</Card.Text>
                <Card.Text>Quantity: {item.quantity}</Card.Text>
                <Card.Text>
                  Subtotal: ₹{item.quantity * parseInt(item.price.replace("₹", ""))}
                </Card.Text>
                <Button variant="danger" onClick={() => removeFromCart(item.name)}>
                  Remove
                </Button>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>
      {cartItems.length > 0 && !paymentSuccess && (
        <>
          <div className="mt-4 cart-summary">
            <h4>Order Summary</h4>
            <div className="d-flex justify-content-between">
              <span>Subtotal:</span>
              <span>₹{subtotal}</span>
            </div>
            
            {discount.amount > 0 && (
              <div className="d-flex justify-content-between text-success">
                <span>Discount ({discount.percentage}%):</span>
                <span>-₹{discount.amount}</span>
              </div>
            )}
            
            <div className="d-flex justify-content-between fw-bold mt-2">
              <span>Total:</span>
              <span>₹{total}</span>
            </div>
            
            {discount.amount === 0 && subtotal > 0 && (
              <div className="mt-2 text-muted small">
                <p>Add more items to qualify for a discount:</p>
                <ul>
                  {discountTiers.map((tier, index) => (
                    <li key={index}>
                      Spend ₹{tier.threshold} or more for {tier.percentage}% off
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          <Form className="my-3">
            <Form.Group>
              <Form.Label>Delivery Address</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter your address"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
              />
            </Form.Group>
          </Form>
          <Button variant="success" onClick={handlePayment} disabled={!address.trim()}>
            Pay Now
          </Button>
        </>
      )}
      {paymentSuccess && (
        <div className="mt-4">
          <h4>🎉 Payment Successful!</h4>
          <p>Your order will be delivered to: <strong>{address}</strong></p>
        </div>
      )}
      {/* Order History */}
      <div className="order-history mt-5">
        <h3>Order History</h3>
        {orderHistory.length === 0 ? (
          <p>No previous orders found.</p>
        ) : (
          <Row>
            {orderHistory.map((order, index) => (
              <Col md={6} lg={4} key={index} className="mb-4">
                <Card>
                  <Card.Body>
                    <Card.Title>Order placed on {order.date}</Card.Title>
                    <Card.Text>Subtotal: ₹{order.subtotal}</Card.Text>
                    {order.discount && order.discount.amount > 0 && (
                      <Card.Text className="text-success">
                        Discount ({order.discount.percentage}%): -₹{order.discount.amount}
                      </Card.Text>
                    )}
                    <Card.Text className="fw-bold">Total: ₹{order.total}</Card.Text>
                    <Card.Text>Delivery Address: {order.address}</Card.Text>
                    <ul>
                      {order.items.map((item, idx) => (
                        <li key={idx}>
                          {item.name} - {item.price} x {item.quantity}
                        </li>
                      ))}
                    </ul>
                  </Card.Body>
                </Card>
              </Col>
            ))}
          </Row>
        )}
      </div>
    </div>
  );
};

export default Cart;
