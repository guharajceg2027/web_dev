import React, { useState, useContext } from 'react';
import './Page.css';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { Form, Button, Container, Card, Row, Col, InputGroup } from 'react-bootstrap';
import { FaEnvelope, FaLock, FaEye, FaEyeSlash } from 'react-icons/fa';

const Login = () => {
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();
  const [data, setData] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    
    // Form validation
    if (!data.email || !data.password) {
      setError('Email and password are required');
      return;
    }
    
    try {
      setLoading(true);
      const success = await login(data.email, data.password);
      setLoading(false);
      
      if (success) {
        navigate('/purchase'); // Redirect to purchase after successful login
      } else {
        setError('Invalid email or password');
      }
    } catch (err) {
      setLoading(false);
      setError(err.message || 'Login failed');
    }
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  return (
    <Container className="d-flex justify-content-center align-items-center" style={{ minHeight: "80vh" }}>
      <Row className="w-100 justify-content-center">
        <Col xs={12} sm={10} md={8} lg={5}>
          <Card className="shadow-lg border-0 rounded-lg">
            <Card.Header className="bg-primary text-white text-center py-3">
              <h2 className="fw-bold mb-0">Welcome Back</h2>
              <p className="text-white-50 mb-0">Sign in to your account</p>
            </Card.Header>
            
            <Card.Body className="px-4 py-4">
              {error && (
                <div className="alert alert-danger" role="alert">
                  {error}
                </div>
              )}
              
              <Form onSubmit={handleSubmit}>
                <Form.Group className="mb-4" controlId="formEmail">
                  <Form.Label>Email Address</Form.Label>
                  <InputGroup>
                    <InputGroup.Text className="bg-light">
                      <FaEnvelope />
                    </InputGroup.Text>
                    <Form.Control
                      type="email"
                      placeholder="Enter your email"
                      onChange={(e) => setData({ ...data, email: e.target.value })}
                      value={data.email}
                      required
                      className="py-2"
                    />
                  </InputGroup>
                </Form.Group>
                
                <Form.Group className="mb-4" controlId="formPassword">
                  <Form.Label>Password</Form.Label>
                  <InputGroup>
                    <InputGroup.Text className="bg-light">
                      <FaLock />
                    </InputGroup.Text>
                    <Form.Control
                      type={showPassword ? "text" : "password"}
                      placeholder="Enter your password"
                      onChange={(e) => setData({ ...data, password: e.target.value })}
                      value={data.password}
                      required
                      className="py-2"
                    />
                    <Button 
                      variant="outline-secondary"
                      onClick={togglePasswordVisibility}
                      className="border-start-0"
                    >
                      {showPassword ? <FaEyeSlash /> : <FaEye />}
                    </Button>
                  </InputGroup>
                </Form.Group>
                
                <div className="d-flex justify-content-end mb-4">
                  <Button 
                    variant="link" 
                    className="p-0 text-decoration-none" 
                    onClick={() => navigate('/forgot-password')}
                  >
                    Forgot Password?
                  </Button>
                </div>
                
                <Button 
                  variant="primary" 
                  type="submit" 
                  className="w-100 py-2 mb-3 text-uppercase fw-bold"
                  disabled={loading}
                >
                  {loading ? 'Signing In...' : 'Sign In'}
                </Button>
                
                <div className="text-center">
                  <p className="mb-0">
                    Don't have an account?{' '}
                    <Button 
                      variant="link" 
                      className="p-0" 
                      onClick={() => navigate('/signup')}
                    >
                      Sign up now
                    </Button>
                  </p>
                </div>
              </Form>
            </Card.Body>
          </Card>
          
          <div className="text-center mt-4 text-muted">
            <small>
              By logging in, you agree to our Terms of Service and Privacy Policy
            </small>
          </div>
        </Col>
      </Row>
    </Container>
  );
};

export default Login;
