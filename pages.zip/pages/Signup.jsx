import React, { useState, useContext } from 'react';
import './Page.css';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { Form, Button, Container, Card, Row, Col } from 'react-bootstrap';

const Signup = () => {
  const { signup } = useContext(AuthContext);
  const navigate = useNavigate();
  const [userData, setUserData] = useState({ name: '', email: '', password: '', confirmPassword: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    
    // Form validation
    if (!userData.name || !userData.email || !userData.password || !userData.confirmPassword) {
      setError('All fields are required');
      return;
    }
    
    if (userData.password !== userData.confirmPassword) {
      setError('Passwords do not match');
      return;
    }
    
    if (userData.password.length < 6) {
      setError('Password must be at least 6 characters long');
      return;
    }
    
    try {
      setLoading(true);
      await signup(userData);
      setLoading(false);
      alert("Signup successful! Please login.");
      navigate('/login');
    } catch (err) {
      setLoading(false);
      setError(err.message || 'Failed to create account');
    }
  };

  return (
    <Container className="d-flex justify-content-center align-items-center" style={{ minHeight: "80vh" }}>
      <Row className="w-100 justify-content-center">
        <Col xs={12} sm={10} md={8} lg={6}>
          <Card className="shadow-lg border-0 rounded-lg">
            <Card.Header className="bg-primary text-white text-center py-3">
              <h2 className="fw-bold mb-0">Create Account</h2>
              <p className="text-white-50 mb-0">Join our community today</p>
            </Card.Header>
            
            <Card.Body className="px-4 py-4">
              {error && (
                <div className="alert alert-danger" role="alert">
                  {error}
                </div>
              )}
              
              <Form onSubmit={handleSubmit}>
                <Form.Group className="mb-3" controlId="formName">
                  <Form.Label>Full Name</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Enter your full name"
                    onChange={(e) => setUserData({ ...userData, name: e.target.value })}
                    value={userData.name}
                    required
                    className="py-2"
                  />
                </Form.Group>
                
                <Form.Group className="mb-3" controlId="formEmail">
                  <Form.Label>Email Address</Form.Label>
                  <Form.Control
                    type="email"
                    placeholder="Enter your email"
                    onChange={(e) => setUserData({ ...userData, email: e.target.value })}
                    value={userData.email}
                    required
                    className="py-2"
                  />
                </Form.Group>
                
                <Form.Group className="mb-3" controlId="formPassword">
                  <Form.Label>Password</Form.Label>
                  <Form.Control
                    type="password"
                    placeholder="Create a password"
                    onChange={(e) => setUserData({ ...userData, password: e.target.value })}
                    value={userData.password}
                    required
                    className="py-2"
                  />
                  <Form.Text className="text-muted">
                    Password must be at least 6 characters long
                  </Form.Text>
                </Form.Group>
                
                <Form.Group className="mb-4" controlId="formConfirmPassword">
                  <Form.Label>Confirm Password</Form.Label>
                  <Form.Control
                    type="password"
                    placeholder="Confirm your password"
                    onChange={(e) => setUserData({ ...userData, confirmPassword: e.target.value })}
                    value={userData.confirmPassword}
                    required
                    className="py-2"
                  />
                </Form.Group>
                
                <Button 
                  variant="primary" 
                  type="submit" 
                  className="w-100 py-2 mb-3 text-uppercase fw-bold"
                  disabled={loading}
                >
                  {loading ? 'Creating Account...' : 'Sign Up'}
                </Button>
                
                <div className="text-center">
                  <p className="mb-0">
                    Already have an account?{' '}
                    <Button 
                      variant="link" 
                      className="p-0" 
                      onClick={() => navigate('/login')}
                    >
                      Login here
                    </Button>
                  </p>
                </div>
              </Form>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default Signup;
