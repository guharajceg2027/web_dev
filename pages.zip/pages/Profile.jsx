import React, { useContext, useState } from 'react';
import { Card, Button, Row, Col, Container, Modal, Form } from 'react-bootstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
  faUser, 
  faEnvelope, 
  faMapMarkerAlt, 
  faVenusMars, 
  faPhone, 
  faEdit, 
 // faSignOutAlt 
} from '@fortawesome/free-solid-svg-icons';
import './Page.css';
import { AuthContext } from '../context/AuthContext';

// Local profile images
import maleImg from '../assets/guha.jpeg';
import femaleImg from '../assets/female.jpg';
import otherImg from '../assets/blank.avif';

const Profile = () => {
  const { currentUser, updateUser} = useContext(AuthContext);
  const [showModal, setShowModal] = useState(false);
  const [editedName, setEditedName] = useState(currentUser?.name || '');
  const [editedEmail, setEditedEmail] = useState(currentUser?.email || '');
  const [editedAddress, setEditedAddress] = useState(currentUser?.address || '');
  const [editedGender, setEditedGender] = useState(currentUser?.gender || 'Male');
  const [editedPhone, setEditedPhone] = useState(currentUser?.phone || '');

  const handleShowModal = () => {
    setEditedName(currentUser.name);
    setEditedEmail(currentUser.email);
    setEditedAddress(currentUser.address || '');
    setEditedGender(currentUser.gender || 'Male');
    setEditedPhone(currentUser.phone || '');
    setShowModal(true);
  };
  
  const handleCloseModal = () => setShowModal(false);

  const handleProfileUpdate = () => {
    updateUser({
      ...currentUser,
      name: editedName,
      email: editedEmail,
      address: editedAddress,
      gender: editedGender,
      phone: editedPhone,
    });
    setShowModal(false);
  };

  if (!currentUser) return (
    <Container className="page py-5 text-center">
      <Card className="shadow-lg border-0 p-4">
        <Card.Body>
          <FontAwesomeIcon icon={faUser} size="3x" className="text-muted mb-3" />
          <h3>Please login to view your profile</h3>
          <Button variant="success" href="/login" className="mt-3">
            Go to Login
          </Button>
        </Card.Body>
      </Card>
    </Container>
  );

  // Conditional local profile image
  const profileImage =
    currentUser.gender === 'Female'
      ? femaleImg
      : currentUser.gender === 'Other'
      ? otherImg
      : maleImg;

  return (
    <Container className="page py-5" style={{ maxWidth: '800px', margin: '0 auto' }}>
      <Row className="justify-content-center">
        <Col md={10}>
          <Card className="shadow-lg border-0 overflow-hidden">
          <div className="bg-success bg-gradient text-white p-4 text-center">
  <h2 className="mb-0" style={{ color: '#ffffff' }}>User Profile</h2>
</div>

            <Card.Body className="p-4">
              <div className="text-center mb-4">
                <div className="position-relative d-inline-block">
                  <img
                    src={profileImage}
                    alt="Profile"
                    className="rounded-circle mb-3 border shadow"
                    style={{ width: '150px', height: '150px', objectFit: 'cover' }}
                  />
                </div>
                <h3 className="fw-bold">{currentUser.name}</h3>
                <p className="text-muted">
                  <FontAwesomeIcon icon={faEnvelope} className="me-2" />
                  {currentUser.email}
                </p>
              </div>
              
              <div className="profile-info mb-4 p-4 bg-light rounded">
                <h5 className="fw-bold border-bottom pb-2 mb-3">
                  <FontAwesomeIcon icon={faUser} className="me-2 text-success" />
                  Profile Details
                </h5>
                <Row>
                  <Col md={6} className="mb-3">
                    <div className="d-flex align-items-center">
                      <div className="icon-box bg-success bg-opacity-75 text-white rounded-circle p-2 me-3">
                        <FontAwesomeIcon icon={faUser} />
                      </div>
                      <div>
                        <small className="text-muted d-block">Name</small>
                        <strong className="text-dark">{currentUser.name}</strong>
                      </div>
                    </div>
                  </Col>
                  <Col md={6} className="mb-3">
                    <div className="d-flex align-items-center">
                      <div className="icon-box bg-success bg-opacity-75 text-white rounded-circle p-2 me-3">
                        <FontAwesomeIcon icon={faEnvelope} />
                      </div>
                      <div>
                        <small className="text-muted d-block">Email</small>
                        <strong className="text-dark">{currentUser.email}</strong>
                      </div>
                    </div>
                  </Col>
                  <Col md={6} className="mb-3">
                    <div className="d-flex align-items-center">
                      <div className="icon-box bg-success bg-opacity-75 text-white rounded-circle p-2 me-3">
                        <FontAwesomeIcon icon={faMapMarkerAlt} />
                      </div>
                      <div>
                        <small className="text-muted d-block">Address</small>
                        <strong className="text-dark">{currentUser.address || 'Not provided'}</strong>
                      </div>
                    </div>
                  </Col>
                  <Col md={6} className="mb-3">
                    <div className="d-flex align-items-center">
                      <div className="icon-box bg-success bg-opacity-75 text-white rounded-circle p-2 me-3">
                        <FontAwesomeIcon icon={faVenusMars} />
                      </div>
                      <div>
                        <small className="text-muted d-block">Gender</small>
                        <strong className="text-dark">{currentUser.gender || 'Not provided'}</strong>
                      </div>
                    </div>
                  </Col>
                  <Col md={6} className="mb-3">
                    <div className="d-flex align-items-center">
                      <div className="icon-box bg-success bg-opacity-75 text-white rounded-circle p-2 me-3">
                        <FontAwesomeIcon icon={faPhone} />
                      </div>
                      <div>
                        <small className="text-muted d-block">Phone</small>
                        <strong className="text-dark">{currentUser.phone || 'Not provided'}</strong>
                      </div>
                    </div>
                  </Col>
                </Row>
              </div>
              
              <div className="d-flex justify-content-between">
                <Button 
                  variant="success" 
                  className="px-4 py-2" 
                  onClick={handleShowModal}
                >
                  <FontAwesomeIcon icon={faEdit} className="me-2" />
                  Edit Profile
                </Button>
                {/* <Button 
                  variant="outline-danger" 
                  className="px-4 py-2" 
                  onClick={logout}
                >
                  <FontAwesomeIcon icon={faSignOutAlt} className="me-2" />
                  Logout
                </Button> */}
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      <Modal show={showModal} onHide={handleCloseModal} centered>
        <Modal.Header closeButton className="bg-success bg-gradient text-white">
          <Modal.Title>
            <FontAwesomeIcon icon={faEdit} className="me-2" />
            Edit Profile
          </Modal.Title>
        </Modal.Header>
        <Modal.Body className="p-4">
          <Form>
            <Form.Group controlId="formName" className="mb-3">
              <Form.Label>
                <FontAwesomeIcon icon={faUser} className="me-2 text-success" />
                Name
              </Form.Label>
              <Form.Control
                type="text"
                value={editedName}
                onChange={(e) => setEditedName(e.target.value)}
                placeholder="Enter your name"
                className="py-2"
              />
            </Form.Group>
            <Form.Group controlId="formEmail" className="mb-3">
              <Form.Label>
                <FontAwesomeIcon icon={faEnvelope} className="me-2 text-success" />
                Email
              </Form.Label>
              <Form.Control
                type="email"
                value={editedEmail}
                onChange={(e) => setEditedEmail(e.target.value)}
                placeholder="Enter your email"
                className="py-2"
              />
            </Form.Group>
            <Form.Group controlId="formAddress" className="mb-3">
              <Form.Label>
                <FontAwesomeIcon icon={faMapMarkerAlt} className="me-2 text-success" />
                Address
              </Form.Label>
              <Form.Control
                type="text"
                value={editedAddress}
                onChange={(e) => setEditedAddress(e.target.value)}
                placeholder="Enter your address"
                className="py-2"
              />
            </Form.Group>
            <Form.Group controlId="formGender" className="mb-3">
              <Form.Label>
                <FontAwesomeIcon icon={faVenusMars} className="me-2 text-success" />
                Gender
              </Form.Label>
              <Form.Select
                value={editedGender}
                onChange={(e) => setEditedGender(e.target.value)}
                className="py-2"
              >
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </Form.Select>
            </Form.Group>
            <Form.Group controlId="formPhone" className="mb-3">
              <Form.Label>
                <FontAwesomeIcon icon={faPhone} className="me-2 text-success" />
                Phone
              </Form.Label>
              <Form.Control
                type="text"
                value={editedPhone}
                onChange={(e) => setEditedPhone(e.target.value)}
                placeholder="Enter your phone number"
                className="py-2"
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseModal}>
            Cancel
          </Button>
          <Button variant="success" onClick={handleProfileUpdate}>
            <FontAwesomeIcon icon={faEdit} className="me-2" />
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  );
};

export default Profile;
